import { useEffect } from 'react';

export default function Home() {
  useEffect(() => {
    // Import scripts on component mount
    const scriptElement = document.createElement('script');
    scriptElement.src = '/src/assets/js/script.js';
    document.body.appendChild(scriptElement);

    const bookingScriptElement = document.createElement('script');
    bookingScriptElement.src = '/src/assets/js/booking.js';
    document.body.appendChild(bookingScriptElement);

    // Cleanup on component unmount
    return () => {
      document.body.removeChild(scriptElement);
      document.body.removeChild(bookingScriptElement);
    };
  }, []);

  return (
    <>
      {/* Header */}
      <header className="sticky top-0 z-50 bg-cream bg-opacity-95 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl md:text-3xl font-playfair font-bold text-brown">
              <span className="text-terracotta">Lofi</span>-<span>Coffi</span>
            </h1>
          </div>
          
          {/* Mobile menu button */}
          <button id="menu-toggle" className="md:hidden text-brown focus:outline-none">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          
          {/* Desktop navigation */}
          <nav className="hidden md:flex space-x-8 text-sm">
            <a href="#home" className="nav-link font-medium text-brown hover:text-brown-light">Home</a>
            <a href="#about" className="nav-link font-medium text-brown hover:text-brown-light">About Us</a>
            <a href="#menu" className="nav-link font-medium text-brown hover:text-brown-light">Coffee Menu</a>
            <a href="#booking" className="nav-link font-medium text-brown hover:text-brown-light">Book a Table</a>
            <a href="#contact" className="nav-link font-medium text-brown hover:text-brown-light">Contact</a>
          </nav>
        </div>
        
        {/* Mobile navigation */}
        <nav id="mobile-menu" className="hidden px-4 py-3 bg-cream md:hidden">
          <div className="flex flex-col space-y-3">
            <a href="#home" className="py-2 font-medium text-brown hover:text-brown-light">Home</a>
            <a href="#about" className="py-2 font-medium text-brown hover:text-brown-light">About Us</a>
            <a href="#menu" className="py-2 font-medium text-brown hover:text-brown-light">Coffee Menu</a>
            <a href="#booking" className="py-2 font-medium text-brown hover:text-brown-light">Book a Table</a>
            <a href="#contact" className="py-2 font-medium text-brown hover:text-brown-light">Contact</a>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative h-screen">
        <div className="absolute inset-0 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80" 
            alt="Cozy coffee shop interior" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 hero-overlay"></div>
        </div>
        
        <div className="relative container mx-auto px-4 h-full flex flex-col justify-center">
          <div className="max-w-xl">
            <h1 className="font-playfair text-4xl md:text-6xl font-bold text-white mb-4">
              Experience tranquility <br />in every sip
            </h1>
            <p className="text-lg md:text-xl text-cream mb-8">
              A peaceful haven where premium coffee meets the soothing vibes of lofi music.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="#booking" className="px-6 py-3 bg-terracotta text-white font-medium rounded-lg text-center hover:bg-terracotta-light transition-colors">
                Book a Table
              </a>
              <a href="#menu" className="px-6 py-3 bg-transparent border-2 border-cream text-cream font-medium rounded-lg text-center hover:bg-cream hover:text-brown transition-colors">
                Explore Our Menu
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about" className="py-16 md:py-24 bg-cream">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-brown mb-4">Our Story</h2>
            <p className="text-lg text-brown-dark">
              Welcome to Lofi-Coffi, where exceptional coffee and tranquil atmosphere create a unique experience.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <h3 className="font-playfair text-2xl font-semibold text-brown mb-4">A sanctuary of calm</h3>
              <p className="mb-4 text-brown-dark">
                Lofi-Coffi was born from a simple idea: create a space where people can escape the hustle of everyday life while enjoying premium, ethically-sourced coffee.
              </p>
              <p className="mb-4 text-brown-dark">
                Our coffee shop combines the relaxing beats of lofi music with the rich aromas of specialty coffee. We've carefully crafted an environment that promotes relaxation, focus, and connection.
              </p>
              <p className="mb-6 text-brown-dark">
                We partner exclusively with sustainable coffee farms and use only the highest quality beans, roasted to perfection to bring out their unique flavor profiles.
              </p>
              <div className="flex items-center">
                <img 
                  src="https://images.unsplash.com/photo-1573267066195-2b696047d6a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80" 
                  alt="Coffee beans" 
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <p className="font-caveat text-xl text-brown">James Wilson</p>
                  <p className="text-sm text-brown-light">Founder & Head Barista</p>
                </div>
              </div>
            </div>
            
            <div className="order-1 md:order-2 overflow-hidden rounded-lg shadow-lg image-container">
              <img 
                src="https://images.unsplash.com/photo-1517231925375-bf2cb42917a5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Cozy coffee shop interior with lofi aesthetic" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          
          <div className="mt-20">
            <h3 className="font-playfair text-2xl font-semibold text-brown text-center mb-10">Why Choose Us?</h3>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md hover-scale">
                <div className="w-12 h-12 bg-sage rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h4 className="font-playfair text-xl font-semibold mb-2">Premium Beans</h4>
                <p className="text-brown-dark">We source our beans from the world's finest sustainable farms, ensuring every cup is exceptional.</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md hover-scale">
                <div className="w-12 h-12 bg-sage rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                  </svg>
                </div>
                <h4 className="font-playfair text-xl font-semibold mb-2">Lofi Atmosphere</h4>
                <p className="text-brown-dark">Our carefully curated lofi playlists create the perfect ambiance for relaxation and focus.</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md hover-scale">
                <div className="w-12 h-12 bg-sage rounded-full flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                <h4 className="font-playfair text-xl font-semibold mb-2">Expert Baristas</h4>
                <p className="text-brown-dark">Our skilled baristas are trained in the art of coffee preparation, ensuring a perfect cup every time.</p>
              </div>
            </div>
          </div>
          
          <div className="mt-20">
            <h3 className="font-playfair text-2xl font-semibold text-brown text-center mb-10">Our Brands & Equipment</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="bg-white p-4 rounded-lg text-center shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1610889556528-9a770e32642f?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                  alt="Premium coffee beans" 
                  className="w-full h-32 object-contain mb-3"
                />
                <p className="font-medium text-brown">Stumptown Coffee</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg text-center shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1622480916113-9000ac49b79d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                  alt="Coffee brewing equipment" 
                  className="w-full h-32 object-contain mb-3"
                />
                <p className="font-medium text-brown">La Marzocco</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg text-center shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1574914629385-46e8d43a7ccd?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                  alt="Coffee grinder" 
                  className="w-full h-32 object-contain mb-3"
                />
                <p className="font-medium text-brown">Mahlkönig</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg text-center shadow-md">
                <img 
                  src="https://images.unsplash.com/photo-1611854779393-1b2da9d400fe?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                  alt="Coffee beans" 
                  className="w-full h-32 object-contain mb-3"
                />
                <p className="font-medium text-brown">Counter Culture</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Coffee Menu Section */}
      <section id="menu" className="py-16 md:py-24 bg-beige">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-brown mb-4">Our Coffee Menu</h2>
            <p className="text-lg text-brown-dark">
              Explore our selection of specialty coffees, carefully crafted to perfection.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div className="order-2 md:order-1">
              <h3 className="font-playfair text-2xl font-semibold text-brown mb-6">Signature Drinks</h3>
              
              <div className="space-y-6">
                <div className="bg-white p-5 rounded-lg shadow-md hover-scale">
                  <div className="flex justify-between items-start mb-3">
                    <h4 className="font-playfair text-xl font-semibold text-brown">Lofi Latte</h4>
                    <span className="font-medium text-brown">$4.95</span>
                  </div>
                  <p className="text-brown-dark mb-4">
                    Our signature latte with house-made vanilla syrup, topped with velvety microfoam and a dash of cinnamon.
                  </p>
                  <div className="flex items-center text-sm text-brown-light space-x-3">
                    <span className="px-2 py-1 bg-cream rounded-full">Specialty</span>
                    <span className="px-2 py-1 bg-cream rounded-full">House Favorite</span>
                  </div>
                </div>
                
                <div className="bg-white p-5 rounded-lg shadow-md hover-scale">
                  <div className="flex justify-between items-start mb-3">
                    <h4 className="font-playfair text-xl font-semibold text-brown">Chill Wave Cold Brew</h4>
                    <span className="font-medium text-brown">$5.50</span>
                  </div>
                  <p className="text-brown-dark mb-4">
                    24-hour steeped cold brew with notes of chocolate and citrus, served over ice with your choice of cream.
                  </p>
                  <div className="flex items-center text-sm text-brown-light space-x-3">
                    <span className="px-2 py-1 bg-cream rounded-full">Refreshing</span>
                    <span className="px-2 py-1 bg-cream rounded-full">Low Acidity</span>
                  </div>
                </div>
                
                <div className="bg-white p-5 rounded-lg shadow-md hover-scale">
                  <div className="flex justify-between items-start mb-3">
                    <h4 className="font-playfair text-xl font-semibold text-brown">Tranquil Mocha</h4>
                    <span className="font-medium text-brown">$5.25</span>
                  </div>
                  <p className="text-brown-dark mb-4">
                    Espresso blended with our house-made chocolate ganache and steamed milk, topped with cocoa dust.
                  </p>
                  <div className="flex items-center text-sm text-brown-light space-x-3">
                    <span className="px-2 py-1 bg-cream rounded-full">Rich</span>
                    <span className="px-2 py-1 bg-cream rounded-full">Indulgent</span>
                  </div>
                </div>
              </div>
              
              <h3 className="font-playfair text-2xl font-semibold text-brown mt-10 mb-6">Classic Options</h3>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="border-b pb-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Espresso</span>
                      <span>$3.00</span>
                    </div>
                  </div>
                  
                  <div className="border-b pb-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Cappuccino</span>
                      <span>$4.25</span>
                    </div>
                  </div>
                  
                  <div className="border-b pb-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Americano</span>
                      <span>$3.50</span>
                    </div>
                  </div>
                  
                  <div className="border-b pb-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Flat White</span>
                      <span>$4.50</span>
                    </div>
                  </div>
                  
                  <div className="border-b pb-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Macchiato</span>
                      <span>$3.75</span>
                    </div>
                  </div>
                  
                  <div className="border-b pb-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Pour Over</span>
                      <span>$4.50</span>
                    </div>
                  </div>
                  
                  <div className="pb-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Chai Latte</span>
                      <span>$4.75</span>
                    </div>
                  </div>
                  
                  <div className="pb-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Herbal Tea</span>
                      <span>$3.50</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="order-1 md:order-2 space-y-6">
              <div className="overflow-hidden rounded-lg shadow-lg image-container">
                <img 
                  src="https://images.unsplash.com/photo-1541167760496-1628856ab772?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Specialty coffee latte with latte art" 
                  className="w-full h-80 object-cover"
                />
              </div>
              
              <div className="overflow-hidden rounded-lg shadow-lg image-container">
                <img 
                  src="https://images.unsplash.com/photo-1498804103079-a6351b050096?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Coffee being prepared with pour-over method" 
                  className="w-full h-80 object-cover"
                />
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h4 className="font-playfair text-xl font-semibold text-brown mb-4">This Month's Origin</h4>
                <div className="flex items-start">
                  <img 
                    src="https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?ixlib=rb-1.2.1&auto=format&fit=crop&w=240&q=80" 
                    alt="Coffee beans from Ethiopia" 
                    className="w-20 h-20 rounded-lg object-cover mr-4"
                  />
                  <div>
                    <h5 className="font-medium mb-1">Ethiopian Yirgacheffe</h5>
                    <p className="text-sm text-brown-dark mb-2">
                      Bright, floral notes with hints of citrus and berries. Medium body with a clean finish.
                    </p>
                    <span className="text-xs text-brown-light">Available as pour-over and batch brew</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-16 bg-cream">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-brown mb-4">The Lofi-Coffi Experience</h2>
            <p className="text-lg text-brown-dark">
              Snippets of the calm and quality that define our coffee shop.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="overflow-hidden rounded-lg shadow-md image-container aspect-square">
              <img 
                src="https://images.unsplash.com/photo-1524758631624-e2822e304c36?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Cozy coffee shop interior with wood elements" 
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="overflow-hidden rounded-lg shadow-md image-container aspect-square">
              <img 
                src="https://images.unsplash.com/photo-1620360289-bbc503222d76?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Barista preparing specialty coffee" 
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="overflow-hidden rounded-lg shadow-md image-container aspect-square">
              <img 
                src="https://images.unsplash.com/photo-1445116572660-236099ec97a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="People relaxing and working in coffee shop" 
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="overflow-hidden rounded-lg shadow-md image-container aspect-square">
              <img 
                src="https://images.unsplash.com/photo-1510972527921-ce03766a1cf1?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Coffee beans being roasted" 
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="overflow-hidden rounded-lg shadow-md image-container aspect-square">
              <img 
                src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Coffee shop outdoor seating area" 
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="overflow-hidden rounded-lg shadow-md image-container aspect-square">
              <img 
                src="https://images.unsplash.com/photo-1501443762994-82bd5dace89a?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Latte art in coffee cup" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section id="booking" className="py-16 md:py-24 bg-sage bg-opacity-10">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-brown mb-4">Book Your Visit</h2>
            <p className="text-lg text-brown-dark">
              Reserve a table at Lofi-Coffi and ensure your spot in our tranquil space.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="md:flex">
              {/* Left section: Image */}
              <div className="md:w-1/3 relative">
                <img 
                  src="https://images.unsplash.com/photo-1530610476181-d83430b64dcd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Cozy coffee shop seating area" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-brown-dark bg-opacity-40 flex flex-col justify-center items-center text-center p-6">
                  <h3 className="font-playfair text-2xl text-white font-semibold mb-3">Reserve Your Space</h3>
                  <p className="text-cream mb-2">Open daily from 7am to 8pm</p>
                  <p className="text-cream text-sm">Reservations recommended for groups of 4+</p>
                </div>
              </div>
              
              {/* Right section: Booking form */}
              <div className="md:w-2/3 p-6 md:p-8">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Calendar */}
                  <div>
                    <h4 className="font-medium text-lg mb-4">Select Date</h4>
                    
                    <div className="calendar">
                      <div className="calendar-header">
                        <button id="prev-month" className="text-brown hover:text-brown-light focus:outline-none">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
                          </svg>
                        </button>
                        <h5 id="current-month" className="font-medium">October 2023</h5>
                        <button id="next-month" className="text-brown hover:text-brown-light focus:outline-none">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                          </svg>
                        </button>
                      </div>
                      
                      <div className="calendar-grid">
                        <div className="calendar-weekday">Su</div>
                        <div className="calendar-weekday">Mo</div>
                        <div className="calendar-weekday">Tu</div>
                        <div className="calendar-weekday">We</div>
                        <div className="calendar-weekday">Th</div>
                        <div className="calendar-weekday">Fr</div>
                        <div className="calendar-weekday">Sa</div>
                      </div>
                      
                      <div id="calendar-days" className="calendar-grid">
                        {/* Calendar days will be generated by JavaScript */}
                      </div>
                    </div>
                    
                    <div className="mt-4 text-sm flex items-center space-x-4">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-sage rounded-full mr-2"></div>
                        <span>Selected</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-gray-200 rounded-full mr-2"></div>
                        <span>Unavailable</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Form */}
                  <div>
                    <h4 className="font-medium text-lg mb-4">Reservation Details</h4>
                    
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-brown-dark mb-1" htmlFor="time">
                        Select Time
                      </label>
                      <div className="time-slots grid grid-cols-3 gap-2">
                        {/* Time slots will be generated by JavaScript */}
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-brown-dark mb-1" htmlFor="guests">
                        Number of Guests
                      </label>
                      <select id="guests" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sage focus:border-transparent">
                        <option value="1">1 person</option>
                        <option value="2" selected>2 people</option>
                        <option value="3">3 people</option>
                        <option value="4">4 people</option>
                        <option value="5">5 people</option>
                        <option value="6">6+ people (please specify in notes)</option>
                      </select>
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-brown-dark mb-1" htmlFor="name">
                        Your Name
                      </label>
                      <input type="text" id="name" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sage focus:border-transparent" placeholder="Full name" />
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-brown-dark mb-1" htmlFor="email">
                        Email Address
                      </label>
                      <input type="email" id="email" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sage focus:border-transparent" placeholder="your@email.com" />
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-sm font-medium text-brown-dark mb-1" htmlFor="notes">
                        Special Requests (Optional)
                      </label>
                      <textarea id="notes" rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sage focus:border-transparent" placeholder="Any special requests or preferences?"></textarea>
                    </div>
                    
                    <button id="book-table" className="w-full bg-brown hover:bg-brown-light text-white py-3 px-4 rounded-md transition-colors">
                      Confirm Reservation
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-24 bg-cream">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-brown mb-4">Visit Us</h2>
            <p className="text-lg text-brown-dark">
              We'd love to see you at Lofi-Coffi. Here's how to find us.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                <h3 className="font-playfair text-2xl font-semibold text-brown mb-4">Our Location</h3>
                
                <div className="flex items-start mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-sage mr-3 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <div>
                    <p className="font-medium text-brown-dark">123 Tranquility Lane</p>
                    <p className="text-brown-dark">Portland, OR 97204</p>
                  </div>
                </div>
                
                <div className="flex items-start mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-sage mr-3 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <p className="font-medium text-brown-dark">Opening Hours</p>
                    <p className="text-brown-dark">Monday - Friday: 7am - 8pm</p>
                    <p className="text-brown-dark">Saturday - Sunday: 8am - 9pm</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-sage mr-3 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <div>
                    <p className="font-medium text-brown-dark">Contact Us</p>
                    <p className="text-brown-dark">Phone: (555) 123-4567</p>
                    <p className="text-brown-dark">Email: hello@loficoffi.com</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="font-playfair text-2xl font-semibold text-brown mb-4">Send Us a Message</h3>
                
                <form id="contact-form">
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-brown-dark mb-1" htmlFor="contact-name">
                      Your Name
                    </label>
                    <input type="text" id="contact-name" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sage focus:border-transparent" placeholder="Full name" />
                  </div>
                  
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-brown-dark mb-1" htmlFor="contact-email">
                      Email Address
                    </label>
                    <input type="email" id="contact-email" className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sage focus:border-transparent" placeholder="your@email.com" />
                  </div>
                  
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-brown-dark mb-1" htmlFor="message">
                      Your Message
                    </label>
                    <textarea id="message" rows={4} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sage focus:border-transparent" placeholder="How can we help you?"></textarea>
                  </div>
                  
                  <button type="submit" className="bg-sage hover:bg-sage-light text-white py-2 px-4 rounded-md transition-colors">
                    Send Message
                  </button>
                </form>
              </div>
            </div>
            
            <div className="h-full">
              <div className="bg-white p-2 rounded-lg shadow-md h-full">
                {/* Map placeholder - would be replaced with actual map in production */}
                <div className="bg-beige h-full rounded-md flex items-center justify-center">
                  <div className="text-center p-6">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-sage mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                    </svg>
                    <p className="text-brown font-medium mb-2">Map View</p>
                    <p className="text-sm text-brown-light">Interactive map showing Lofi-Coffi location at 123 Tranquility Lane, Portland, OR</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-brown-dark text-cream py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-playfair text-xl font-bold mb-4">Lofi-Coffi</h3>
              <p className="mb-4 text-sm text-cream opacity-80">
                A tranquil coffee haven where premium beans meet lofi vibes, creating the perfect space for relaxation and focus.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-cream hover:text-terracotta transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm3 8h-1.35c-.538 0-.65.221-.65.778v1.222h2l-.209 2h-1.791v7h-3v-7h-2v-2h2v-2.308c0-1.769.931-2.692 3.029-2.692h1.971v3z"/>
                  </svg>
                </a>
                <a href="#" className="text-cream hover:text-terracotta transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6.066 9.645c.183 4.04-2.83 8.544-8.164 8.544-1.622 0-3.131-.476-4.402-1.291 1.524.18 3.045-.244 4.252-1.189-1.256-.023-2.317-.854-2.684-1.995.451.086.895.061 1.298-.049-1.381-.278-2.335-1.522-2.304-2.853.388.215.83.344 1.301.359-1.279-.855-1.641-2.544-.889-3.835 1.416 1.738 3.533 2.881 5.92 3.001-.419-1.796.944-3.527 2.799-3.527.825 0 1.572.349 2.096.907.654-.128 1.27-.368 1.824-.697-.215.671-.67 1.233-1.263 1.589.581-.07 1.135-.224 1.649-.453-.384.578-.87 1.084-1.433 1.489z"/>
                  </svg>
                </a>
                <a href="#" className="text-cream hover:text-terracotta transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-2 16h-2v-6h2v6zm-1-6.891c-.607 0-1.1-.496-1.1-1.109 0-.612.492-1.109 1.1-1.109s1.1.497 1.1 1.109c0 .613-.493 1.109-1.1 1.109zm8 6.891h-1.998v-2.861c0-1.881-2.002-1.722-2.002 0v2.861h-2v-6h2v1.093c.872-1.616 4-1.736 4 1.548v3.359z"/>
                  </svg>
                </a>
                <a href="#" className="text-cream hover:text-terracotta transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-2 16h-2v-6h2v6zm-1-6.891c-.607 0-1.1-.496-1.1-1.109 0-.612.492-1.109 1.1-1.109s1.1.497 1.1 1.109c0 .613-.493 1.109-1.1 1.109zm8 6.891h-1.998v-2.861c0-1.881-2.002-1.722-2.002 0v2.861h-2v-6h2v1.093c.872-1.616 4-1.736 4 1.548v3.359z"/>
                  </svg>
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-lg mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-cream opacity-80">
                <li><a href="#home" className="hover:text-terracotta transition-colors">Home</a></li>
                <li><a href="#about" className="hover:text-terracotta transition-colors">About Us</a></li>
                <li><a href="#menu" className="hover:text-terracotta transition-colors">Coffee Menu</a></li>
                <li><a href="#booking" className="hover:text-terracotta transition-colors">Book a Table</a></li>
                <li><a href="#contact" className="hover:text-terracotta transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-lg mb-4">Opening Hours</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex justify-between">
                  <span className="text-cream opacity-80">Monday - Friday</span>
                  <span>7am - 8pm</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-cream opacity-80">Saturday</span>
                  <span>8am - 9pm</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-cream opacity-80">Sunday</span>
                  <span>8am - 9pm</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-lg mb-4">Newsletter</h4>
              <p className="mb-4 text-sm text-cream opacity-80">
                Subscribe to our newsletter for updates on events, new coffee arrivals, and special promotions.
              </p>
              <form id="newsletter-form" className="flex">
                <input 
                  type="email" 
                  id="newsletter-email"
                  placeholder="Your email" 
                  className="px-3 py-2 rounded-l-md w-full focus:outline-none text-brown-dark"
                />
                <button type="submit" className="bg-terracotta hover:bg-terracotta-light px-4 py-2 rounded-r-md transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </button>
              </form>
            </div>
          </div>
          
          <div className="border-t border-cream border-opacity-20 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-cream opacity-70 mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} Lofi-Coffi. All rights reserved.
            </p>
            
            <div className="flex space-x-4 text-sm text-cream opacity-70">
              <a href="#" className="hover:text-terracotta transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-terracotta transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-terracotta transition-colors">Accessibility</a>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
