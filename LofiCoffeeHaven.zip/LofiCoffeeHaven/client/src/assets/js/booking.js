// Booking system JavaScript for Lofi-Coffi website

document.addEventListener('DOMContentLoaded', function() {
  // Elements
  const prevMonthBtn = document.getElementById('prev-month');
  const nextMonthBtn = document.getElementById('next-month');
  const currentMonthEl = document.getElementById('current-month');
  const calendarDaysEl = document.getElementById('calendar-days');
  const bookTableBtn = document.getElementById('book-table');
  
  // Store booking data
  let bookingData = {
    date: null,
    time: null,
    guests: 2,
    name: '',
    email: '',
    notes: ''
  };
  
  // Load existing bookings from localStorage
  let existingBookings = JSON.parse(localStorage.getItem('lofiCoffiBookings')) || [];
  
  // Calendar variables
  let currentDate = new Date();
  let currentMonth = currentDate.getMonth();
  let currentYear = currentDate.getFullYear();
  
  // Time slots
  const timeSlots = [
    '10:00 AM', '11:30 AM', '1:00 PM', 
    '2:30 PM', '4:00 PM', '5:30 PM'
  ];
  
  // Unavailable dates (demo purposes)
  const unavailableDates = [
    new Date(currentYear, currentMonth, 5),
    new Date(currentYear, currentMonth, 12),
    new Date(currentYear, currentMonth, 19),
    new Date(currentYear, currentMonth, 26)
  ];
  
  // Unavailable time slots (demo purposes)
  const unavailableTimeSlots = {
    [`${currentYear}-${currentMonth+1}-3`]: ['4:00 PM'],
    [`${currentYear}-${currentMonth+1}-10`]: ['10:00 AM', '2:30 PM'],
    [`${currentYear}-${currentMonth+1}-17`]: ['11:30 AM', '1:00 PM'],
    [`${currentYear}-${currentMonth+1}-24`]: ['5:30 PM']
  };
  
  // Initialize calendar and booking form
  function init() {
    renderCalendar();
    setupEventListeners();
    
    // Pre-select today's date if it's available
    const today = new Date();
    if (today.getMonth() === currentMonth && today.getFullYear() === currentYear) {
      selectDate(today.getDate());
    }
  }
  
  // Render calendar for current month
  function renderCalendar() {
    if (!currentMonthEl || !calendarDaysEl) return;
    
    // Set month and year in header
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 
                   'July', 'August', 'September', 'October', 'November', 'December'];
    currentMonthEl.textContent = `${months[currentMonth]} ${currentYear}`;
    
    // Clear previous calendar days
    calendarDaysEl.innerHTML = '';
    
    // Get first day of month and total days in month
    const firstDay = new Date(currentYear, currentMonth, 1).getDay();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    
    // Create calendar grid with blank spaces for previous month
    for (let i = 0; i < firstDay; i++) {
      const dayEl = document.createElement('div');
      dayEl.className = 'calendar-day inactive';
      calendarDaysEl.appendChild(dayEl);
    }
    
    // Create calendar days for current month
    for (let day = 1; day <= daysInMonth; day++) {
      const dayEl = document.createElement('div');
      dayEl.className = 'calendar-day';
      dayEl.textContent = day;
      
      const dateObj = new Date(currentYear, currentMonth, day);
      
      // Check if date is in the past
      if (dateObj < new Date().setHours(0, 0, 0, 0)) {
        dayEl.className += ' inactive';
      } 
      // Check if date is unavailable
      else if (isDateUnavailable(dateObj)) {
        dayEl.className += ' booked';
      } 
      // Make clickable for available dates
      else {
        dayEl.addEventListener('click', () => selectDate(day));
      }
      
      calendarDaysEl.appendChild(dayEl);
    }
  }
  
  // Check if a date is unavailable
  function isDateUnavailable(date) {
    return unavailableDates.some(unavailableDate => 
      unavailableDate.getDate() === date.getDate() &&
      unavailableDate.getMonth() === date.getMonth() &&
      unavailableDate.getFullYear() === date.getFullYear()
    );
  }
  
  // Select a date
  function selectDate(day) {
    // Update selected date in UI
    document.querySelectorAll('.calendar-day').forEach(el => {
      el.classList.remove('selected');
      if (el.textContent == day && !el.classList.contains('inactive') && !el.classList.contains('booked')) {
        el.classList.add('selected');
      }
    });
    
    // Update booking data
    bookingData.date = new Date(currentYear, currentMonth, day);
    
    // Render time slots for selected date
    renderTimeSlots();
  }
  
  // Render time slots based on selected date
  function renderTimeSlots() {
    const timeSlotsContainer = document.querySelector('.time-slots');
    if (!timeSlotsContainer) return;
    
    timeSlotsContainer.innerHTML = '';
    
    // Get unavailable time slots for selected date
    const dateKey = `${currentYear}-${currentMonth+1}-${bookingData.date.getDate()}`;
    const unavailableTimes = unavailableTimeSlots[dateKey] || [];
    
    // Create time slot buttons
    timeSlots.forEach(time => {
      const timeSlotBtn = document.createElement('button');
      timeSlotBtn.className = 'time-slot';
      timeSlotBtn.textContent = time;
      
      // Check if time slot is unavailable
      if (unavailableTimes.includes(time)) {
        timeSlotBtn.className += ' booked';
        timeSlotBtn.setAttribute('disabled', true);
      } else {
        timeSlotBtn.addEventListener('click', () => selectTimeSlot(time));
        
        // Check if this time slot is currently selected
        if (bookingData.time === time) {
          timeSlotBtn.className += ' selected';
        }
      }
      
      timeSlotsContainer.appendChild(timeSlotBtn);
    });
  }
  
  // Select a time slot
  function selectTimeSlot(time) {
    // Update selected time in UI
    document.querySelectorAll('.time-slot').forEach(el => {
      el.classList.remove('selected');
      if (el.textContent === time) {
        el.classList.add('selected');
      }
    });
    
    // Update booking data
    bookingData.time = time;
  }
  
  // Setup event listeners
  function setupEventListeners() {
    // Previous month button
    if (prevMonthBtn) {
      prevMonthBtn.addEventListener('click', () => {
        currentMonth--;
        if (currentMonth < 0) {
          currentMonth = 11;
          currentYear--;
        }
        renderCalendar();
      });
    }
    
    // Next month button
    if (nextMonthBtn) {
      nextMonthBtn.addEventListener('click', () => {
        currentMonth++;
        if (currentMonth > 11) {
          currentMonth = 0;
          currentYear++;
        }
        renderCalendar();
      });
    }
    
    // Number of guests select
    const guestsSelect = document.getElementById('guests');
    if (guestsSelect) {
      guestsSelect.addEventListener('change', function() {
        bookingData.guests = parseInt(this.value);
      });
    }
    
    // Name input
    const nameInput = document.getElementById('name');
    if (nameInput) {
      nameInput.addEventListener('input', function() {
        bookingData.name = this.value;
      });
    }
    
    // Email input
    const emailInput = document.getElementById('email');
    if (emailInput) {
      emailInput.addEventListener('input', function() {
        bookingData.email = this.value;
      });
    }
    
    // Notes textarea
    const notesTextarea = document.getElementById('notes');
    if (notesTextarea) {
      notesTextarea.addEventListener('input', function() {
        bookingData.notes = this.value;
      });
    }
    
    // Book table button
    if (bookTableBtn) {
      bookTableBtn.addEventListener('click', submitBooking);
    }
  }
  
  // Submit booking
  function submitBooking() {
    // Validate form
    if (!bookingData.date || !bookingData.time) {
      alert('Please select a date and time for your reservation');
      return;
    }
    
    if (!bookingData.name) {
      alert('Please enter your name');
      return;
    }
    
    if (!bookingData.email) {
      alert('Please enter your email address');
      return;
    }
    
    // Format date for display
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const formattedDate = bookingData.date.toLocaleDateString('en-US', options);
    
    // Save booking to localStorage
    const booking = {
      ...bookingData,
      id: Date.now(),
      date: bookingData.date.toISOString()
    };
    
    existingBookings.push(booking);
    localStorage.setItem('lofiCoffiBookings', JSON.stringify(existingBookings));
    
    // Show confirmation
    alert(`Thank you! Your reservation has been confirmed for ${formattedDate} at ${bookingData.time}. We look forward to seeing you at Lofi-Coffi.`);
    
    // Reset form
    resetBookingForm();
  }
  
  // Reset booking form
  function resetBookingForm() {
    bookingData = {
      date: null,
      time: null,
      guests: 2,
      name: '',
      email: '',
      notes: ''
    };
    
    // Reset UI elements
    document.querySelectorAll('.calendar-day').forEach(el => {
      el.classList.remove('selected');
    });
    
    document.querySelectorAll('.time-slot').forEach(el => {
      el.classList.remove('selected');
    });
    
    document.getElementById('guests').value = "2";
    document.getElementById('name').value = "";
    document.getElementById('email').value = "";
    document.getElementById('notes').value = "";
  }
  
  // Initialize booking system
  init();
});
