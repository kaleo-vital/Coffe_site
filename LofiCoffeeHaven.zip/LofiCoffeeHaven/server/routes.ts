import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for bookings
  app.get("/api/bookings", async (req, res) => {
    try {
      const bookings = await storage.getAllBookings();
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get bookings" });
    }
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      const { date, time, guests, name, email, notes } = req.body;
      
      // Validate required fields
      if (!date || !time || !guests || !name || !email) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const booking = await storage.createBooking({
        date,
        time,
        guests,
        name,
        email,
        notes: notes || "",
      });

      res.status(201).json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  app.get("/api/bookings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }

      const booking = await storage.getBooking(id);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }

      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to get booking" });
    }
  });

  app.delete("/api/bookings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }

      const success = await storage.deleteBooking(id);
      if (!success) {
        return res.status(404).json({ message: "Booking not found" });
      }

      res.json({ message: "Booking deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete booking" });
    }
  });

  // API routes for contact form
  app.post("/api/contact", async (req, res) => {
    try {
      const { name, email, message } = req.body;
      
      // Validate required fields
      if (!name || !email || !message) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const contact = await storage.createContactMessage({
        name,
        email,
        message,
      });

      res.status(201).json(contact);
    } catch (error) {
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // API routes for newsletter
  app.post("/api/newsletter", async (req, res) => {
    try {
      const { email } = req.body;
      
      // Validate required fields
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      const subscriber = await storage.createNewsletterSubscription({
        email,
      });

      res.status(201).json(subscriber);
    } catch (error) {
      res.status(500).json({ message: "Failed to subscribe to newsletter" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
